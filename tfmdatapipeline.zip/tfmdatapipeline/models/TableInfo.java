package com.efx.ews.tfm.tfmdatapipeline.models;

import lombok.Data;

@Data
public class  TableInfo{
    private String tableName;
    private String columnName;
    private boolean isPII;
}
