package com.efx.ews.tfm.tfmdatapipeline;

import com.efx.ews.tfm.tfmdatapipeline.models.TableDetail;
import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.options.Default;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.Validation;
import org.apache.beam.sdk.options.ValueProvider;

public interface TfmDataPipelineOptions extends DataflowPipelineOptions {

    @Description("Input file name")
    ValueProvider<String> getInputFileName();
    void setInputFileName(ValueProvider<String> value);

//    @Description("JSON Schema file name")
//    ValueProvider<String> getJsonSchema();
//    void setJsonSchema(ValueProvider<String> value);

    @Description("Output Folder file name")
    ValueProvider<String> getOutputFolder();
    void setOutputFolder(ValueProvider<String> value);

    @Description("Operation type")
    ValueProvider<String> getOperation();
    void setOperation(ValueProvider<String> value);

    @Description("Output file name")
    ValueProvider<String> getOutputFile();
    void setOutputFile(ValueProvider<String> value);

    @Description("CSV to SQL Input file name")
    ValueProvider<String> getCsvtosqlInputFile();
    void setCsvtosqlInputFile(ValueProvider<String> value);

    @Description("CSV to SQL Output file name")
    ValueProvider<String> getSqlOutputFile();
    void setSqlOutputFile(ValueProvider<String> value);

    @Description("SQL to JSON Input file name")
    ValueProvider<String> getSqltojsonInputFile();
    void setSqltojsonInputFile(ValueProvider<String> value);

    @Description("SQL to JSON Output folder name")
    ValueProvider<String> getSqltojsonOutputfiles();
    void setSqltojsonOutputfiles(ValueProvider<String> value);

    @Description("PGP Public key")
    ValueProvider<String> getPgpPublicKey();
    void setPgpPublicKey(ValueProvider<String> value);

    @Description("PGP Private key")
    ValueProvider<String> getPgpPrivateKey();
    void setPgpPrivateKey(ValueProvider<String> value);

    @Description("File name to PGP encrypt")
    ValueProvider<String> getFileToPgpEncrypt();
    void setFileToPgpEncrypt(ValueProvider<String> value);

    @Description("PGP Encrypted File Path")
    ValueProvider<String> getPgpEncryptedFilePath();
    void setPgpEncryptedFilePath(ValueProvider<String> value);

    @Description("PGP Decrypted File Path")
    ValueProvider<String> getPgpDecryptedFilePath();
    void setPgpDecryptedFilePath(ValueProvider<String> value);

    @Description("PGP Passphrase")
    ValueProvider<String> getPgpPassPhrase();
    void setPgpPassPhrase(ValueProvider<String> value);

    @Description("Set inputFile required parameter to a file path or glob. A local path and Google Cloud "
                    + "Storage path are both supported.")
    ValueProvider<String> getInputFile();
    void setInputFile(ValueProvider<String> value);

    @Description("Set the Dek file to use for encryption")
    ValueProvider<String> getDekFile();
    void setDekFile(ValueProvider<String> value);

    @Description("Schema file to generate a BigQuery table and convert data to that JSON format.")
    @Default.String("gs://gotpravi/PERSONAL_INFO.json")
    ValueProvider<String> getJsonSchema();
    void setJsonSchema(ValueProvider<String> value);

    @Description("Dataset Name where the data is ingested.")
    @Default.String("jdbc:postgresql://35.231.30.60:5432;databaseName=tfm;user=tfm;password=tfm")
    String getConnectionString();
    void setConnectionString(String value);

    @Description("Formatted Json Schema to be used in Ingestion process")
    TableDetail getTableDetail();
    void setTableDetail(TableDetail value);

    @Description("Parameters for the query - ? for all columns")
    String  getParameterCollection();
    void setParameterCollection(String value);

    @Description("Columns Names for the query")
    String  getColumnCollection();
    void setColumnCollection(String value);
}
