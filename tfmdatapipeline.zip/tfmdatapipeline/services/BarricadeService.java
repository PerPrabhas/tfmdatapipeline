package com.efx.ews.tfm.tfmdatapipeline.services;


import com.equifax.core.barricade.cryptography.crypto.CryptographyServices;
import com.equifax.core.barricade.cryptography.crypto.digest.Digest;
import com.equifax.core.barricade.cryptography.crypto.digest.DigestionContext;
import com.equifax.core.barricade.cryptography.crypto.digest.Digestor;
import com.equifax.core.barricade.cryptography.crypto.digest.impl.BasicDigestionContext;
import com.equifax.core.barricade.cryptography.crypto.encryption.Encryptor;
import com.equifax.core.barricade.cryptography.crypto.util.HashStrength;
import com.equifax.core.barricade.cryptography.crypto.util.internal.SecureRandomCSPRNG;
import com.equifax.core.barricade.cryptography.google.GoogleKeyManager;
import com.equifax.core.barricade.cryptography.impl.BasicCryptographyManager;
import com.equifax.core.barricade.cryptography.key.WrappedKey;
import com.equifax.core.barricade.cryptography.tink.TinkCryptographyServices;
import com.equifax.core.barricade.cryptography.util.impl.BasicEncoding;
import org.apache.beam.sdk.io.FileSystems;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class BarricadeService {

    private static final Logger logger = LoggerFactory.getLogger(BarricadeService.class);

    private final BasicCryptographyManager cm;

    private static final String CHAR_SET = "UTF-8";

    WrappedKey dek;

    public BarricadeService(String dekFile) throws IOException {
        this.cm = new BasicCryptographyManager();
        cm.registerKeyManager(new GoogleKeyManager(new SecureRandomCSPRNG()));
        cm.registerCryptogrpahyServices(new TinkCryptographyServices());

        ReadableByteChannel chan = FileSystems.open(FileSystems.matchNewResource(dekFile, false));
        InputStream stream = Channels.newInputStream(chan);

        logger.info("Loading key \"{}\".", dekFile);
        byte[] serializedKey = loadData(stream);
        dek = cm.decode(new BasicEncoding(serializedKey), WrappedKey.class);
    }

    public String encrypt(String plainText) {
        try {
            CryptographyServices cs = cm.getCryptographyServices();
            Encryptor encryptor = cs.getEncryptor();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            encryptor.encrypt(dek, plainText.getBytes(StandardCharsets.UTF_8), baos, null);
            String output = new String(Base64.getEncoder().encode(baos.toByteArray()));
            return output;
        } catch (Exception e) {
            logger.error("Exception occurred in encrypt method");
            throw e;
        }
    }

    public String hash(String plainText) {
        try {
            CryptographyServices cs = cm.getCryptographyServices();
            //Encryptor encryptor = cs.getEncryptor();
            Digestor digestor = cs.getDigestor();
            DigestionContext context =  new BasicDigestionContext(HashStrength.MINIMMUM);;
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            Digest digest= digestor.hash(plainText.getBytes(StandardCharsets.UTF_8),context);
            //encryptor.encrypt(dek, plainText.getBytes(StandardCharsets.UTF_8), baos, null);
            String output = Base64.getEncoder().encodeToString(digest.getHash());
            //new String(Base64.getEncoder().encode(baos.toByteArray()));
            return output;
        } catch (Exception e) {
            logger.error("Exception occurred in Hash method");
            throw e;
        }
    }

    private byte[] loadData(InputStream file) throws IOException {

        try (BufferedInputStream bis = new BufferedInputStream(file);
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int numRead = -1;
            while ((numRead = bis.read(buffer)) >= 0) {
                baos.write(buffer, 0, numRead);
            }
            return baos.toByteArray();

        }
    }

    public String decrypt(InputStream cipherTextStream) throws UnsupportedEncodingException {
        try {
            BufferedInputStream cipherIS = new BufferedInputStream(Base64.getDecoder().wrap(cipherTextStream));
            CryptographyServices cs = cm.getCryptographyServices();
            Encryptor encryptor = cs.getEncryptor();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            encryptor.decrypt(dek, cipherIS, baos, null);
            String output = baos.toString(CHAR_SET);
            return output;
        } catch (Exception e) {
            logger.error("Exception occurred in decrypt method");
            throw e;
        }
    }
}


