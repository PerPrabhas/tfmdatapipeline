package com.efx.ews.tfm.tfmdatapipeline.models;;

import java.util.List;

import lombok.Data;

@Data
public class TableDetail {
    private String tableName;
    private List<ColumnDetail> fields;
}



