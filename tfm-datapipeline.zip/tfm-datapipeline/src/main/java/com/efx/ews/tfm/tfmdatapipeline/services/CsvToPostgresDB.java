package com.efx.ews.tfm.tfmdatapipeline.services;

import com.efx.ews.tfm.tfmdatapipeline.TfmDataPipelineOptions;
import com.efx.ews.tfm.tfmdatapipeline.models.ColumnDetail;
import com.efx.ews.tfm.tfmdatapipeline.models.TableDetail;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.services.bigquery.model.TableFieldSchema;
import com.google.common.base.Strings;
import com.google.common.io.ByteStreams;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.BigDecimalCoder;
import org.apache.beam.sdk.coders.Coder;
import org.apache.beam.sdk.coders.SerializableCoder;
import org.apache.beam.sdk.io.FileSystems;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.jdbc.JdbcIO;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;

import java.io.*;
import java.math.BigDecimal;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.DataTruncation;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import org.apache.beam.sdk.coders.ListCoder;
import org.apache.beam.sdk.values.PCollection;


public class CsvToPostgresDB {
    private static final long serialVersionUID=1L;
    private static String sourceColumnsName = "fields";
    private static String dateTypeTimeStamp = "TIMESTAMP";
    private static String dataTypeString = "STRING";
    protected static String someSchema="";

    public static class DataInfo implements Serializable {
        private int columnOrderId;
        public String data;
        public String sqlType;
        public String getData() {
            return data;
        }
        public void setData(String data) {
            this.data = data;
        }
        public String getSqlType() {
            return sqlType;
        }
        public void setSqlType(String sqlType) {
            this.sqlType = sqlType;
        }
        public int getColumnOrderId() {
            return columnOrderId;
        }
        public void setColumnOrderId(int columnOrderId) {
            this.columnOrderId = columnOrderId;
        }
    }

    public static class DataProcesser implements Serializable{
        public List<DataInfo> dataInfoList;

        public List<DataInfo> getDataInfoList() {
            return dataInfoList;
        }

        public void setDataInfoList(List<DataInfo> dataInfoList) {
            this.dataInfoList = dataInfoList;
        }
    }

    public static class ConvertCSVtoPostgresQuery extends DoFn<String, DataProcesser> {

//        private static BarricadeService encryptionHelper;
        private String delimiter;
        private String lookAhead = "(?=\")";
        private String lookBehind = "(?<=\")";
        private String nVarCharType ="nvarchar";
        public ConvertCSVtoPostgresQuery(){
            this.delimiter="\\|";
        }

        @ProcessElement
        public void processElement(ProcessContext ctx) throws Exception {

            TfmDataPipelineOptions options = ctx.getPipelineOptions().as(TfmDataPipelineOptions.class);
            String[] rowValues = ctx.element().split(lookBehind + delimiter + lookAhead, -1);
            //String[] rowValues = ctx.element().split( "\\|" );
//            if (encryptionHelper == null) {
//                encryptionHelper = new BarricadeService(options.getDekFile().get());
//            }
            List<DataInfo> dataInfos = new ArrayList<DataInfo>();

            if (rowValues.length!= options.getTableDetail().getFields().size()){
                throw new Exception("Number of columns in CSV file and Json schema does not match");
            }
            List<ColumnDetail> columnDetails=options.getTableDetail().getFields();
            columnDetails.sort(Comparator.comparing(ColumnDetail::getColumnOrderId));
            int columnPosition=0;
            for ( ColumnDetail columnDetail: columnDetails){
                DataInfo dataInfo = new DataInfo();
                //dataInfo.data=rowValues[columnDetail.getColumnOrderId()-1];
                //Remove text qualifiers
//                String data =rowValues[columnDetail.getColumnOrderId()-1].length() > 1
//                        ? rowValues[columnDetail.getColumnOrderId()-1].substring(1, rowValues[columnDetail.getColumnOrderId()-1].length() - 1)
//                        : rowValues[columnDetail.getColumnOrderId()-1];

                String data= rowValues[columnPosition].length() > 1
                        ? rowValues[columnPosition].substring(1, rowValues[columnPosition].length() - 1)
                        : rowValues[columnPosition];

                String sqlDataType =columnDetail.getColumnType();
//                if (columnDetail.getEncryptColumn().equalsIgnoreCase("true") && data.length()>1){
//                    data = encryptionHelper.encrypt(data);
//                    sqlDataType=nVarCharType;
//                }
//                else if (columnDetail.getEncryptColumn().equalsIgnoreCase("hash") && data.length()>1){
//                    data = encryptionHelper.hash(data);
//                    sqlDataType=nVarCharType;
//                }
                dataInfo.data= data;
                dataInfo.sqlType=columnDetail.getColumnType();
                //dataInfo.columnOrderId=columnDetail.getColumnOrderId();
                dataInfo.columnOrderId=columnPosition+1;
                dataInfos.add(dataInfo);
                columnPosition=columnPosition+1;
            }

            DataProcesser dataProcesser = new DataProcesser();
            dataProcesser.setDataInfoList(dataInfos);

            ctx.output(dataProcesser);
        }
    }

    public static void SetTableInformation(TfmDataPipelineOptions options) throws IOException {


        ReadableByteChannel chan = FileSystems.open(FileSystems.matchNewResource(options.getJsonSchema().get(), false));
        byte[] jsonData = new byte[0];
        try (InputStream stream = Channels.newInputStream(chan)){
            jsonData= ByteStreams.toByteArray(stream);
        }
        ObjectMapper objectMapper = new ObjectMapper();
        TableDetail tableDetails = objectMapper.readValue(jsonData, TableDetail.class);
        options.setTableDetail(tableDetails);
        String parameterColumns="";
        String columnCollection="";
        List<ColumnDetail> tempData =tableDetails.getFields();
        tempData.sort(Comparator.comparing(ColumnDetail::getColumnOrderId));
        for (ColumnDetail col : tempData){
            parameterColumns=parameterColumns + "?,";
            columnCollection=columnCollection+ col.getColumnName() +",";
        }
        //Removing the last character as the for loop above adds a comma after the last parameter.
        options.setParameterCollection(parameterColumns.substring(0,parameterColumns.length()-1));
        options.setColumnCollection(columnCollection.substring(0,columnCollection.length()-1));
    }

    public static Boolean CheckForNull(String valueToCheck ){

        //rowValues[col.getColumnOrderId()-1].equalsIgnoreCase("NULL") || rowValues[col.getColumnOrderId()-1].length()<1
        if (valueToCheck.equalsIgnoreCase("NULL") || valueToCheck.length()<1){
            return true;
        }
        return false;

    }

    public static void ProcessPreparedStatement(DataProcesser element, java.sql.PreparedStatement preparedStatement) throws Exception {
        DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS");
        List<CsvToPostgresDB.DataInfo>  data = element.dataInfoList;
        data.sort(Comparator.comparing(CsvToPostgresDB.DataInfo::getColumnOrderId));
        for (CsvToPostgresDB.DataInfo d : data){
            switch( d.sqlType){
                case "decimal":
                    if (CheckForNull(d.data)){
                        preparedStatement.setNull(d.getColumnOrderId(), Types.DECIMAL);
                    }
                    else {
                        preparedStatement.setBigDecimal(d.getColumnOrderId(),  new BigDecimal(d.data));
                    }
                    break;
                case "int":
                    if (CheckForNull(d.data)){
                        preparedStatement.setNull(d.getColumnOrderId(), Types.INTEGER);
                    }
                    else {
                        preparedStatement.setInt(d.getColumnOrderId(), Integer.parseInt(d.data));
                    }
                    break;
                case "bigint":
                    if (CheckForNull(d.data)){
                        preparedStatement.setNull(d.getColumnOrderId(), Types.BIGINT);
                    }
                    else {
                        preparedStatement.setLong(d.getColumnOrderId(),  Long.parseLong(d.data));
                    }
                    break;
                case "bit":
                    if (CheckForNull(d.data)){
                        preparedStatement.setNull(d.getColumnOrderId(),Types.BIT);
                    }
                    else {
                        preparedStatement.setBoolean(d.getColumnOrderId(), Boolean.parseBoolean(d.data));
                    }
                    break;
                case "varbinary":
                    preparedStatement.setBytes(d.getColumnOrderId(), d.data.getBytes());
                    break;
                case "nvarchar":
                case "uniqueidentifier":
                case "ntext":
                    preparedStatement.setString(d.getColumnOrderId(), d.data);
                    break;
                case "datetime":
                    if (CsvToPostgresDB.CheckForNull(d.data)){
                        preparedStatement.setNull(d.getColumnOrderId(), Types.DATE);
                    }
                    else {
                        //java.util.Date colDataDate = inputFormat.parse(d.data);
                        //preparedStatement.setDate(d.getColumnOrderId(), new java.sql.Date(colDataDate.getTime()));
                        preparedStatement.setTimestamp(d.getColumnOrderId(), Timestamp.valueOf(d.data));
                    }
                    break;
                default:
                    throw new Exception("Unknown data type:" + d.sqlType  );
            }

        }
    }
}

