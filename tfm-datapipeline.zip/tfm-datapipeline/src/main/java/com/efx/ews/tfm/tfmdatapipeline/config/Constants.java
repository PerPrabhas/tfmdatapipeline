package com.efx.ews.tfm.tfmdatapipeline.config;

public class Constants {
    public static String startcase="CASE ";
    public static String addWhen="WHEN LOWER(syscol.name) = LOWER('COLUMN_NAME') THEN 'True' ";
    public static String endCase ="ELSE 'False' END as Encrypt  ";
    public static String defaultWithoutCase="'False' as Encrypt";
    public static String startQuery ="select syscol.column_id as col_order_id,sysTab.name as table_name,syscol.name as col_name, sysType.name as col_type ,  ";
    public static String endQuery = " from sys.columns syscol inner join  sys.types sysType on syscol.system_type_id=sysType.system_type_id inner join sys.tables sysTab on sysTab.object_id=syscol.object_id where sysTab.object_id  = (select object_id from sys.tables where name= 'TABLE_NAME') and sysType.name!='sysname' and syscol.is_identity!=1";
    public static String escapeSlash = "/";
    public static String jsonExtn = ".json";

    //public Key
    public static String pgpPublicKey= "src\\main\\resources\\devpublic.asc";
    //private key
    public static String pgpPrivateKey= "src\\main\\resources\\devprivate.asc";
    //sample text file
    public static String fileToPgpEncrypt="src\\main\\resources\\original.txt";
    //file Name after encryption.
    public static String pgpEncryptedFilePath="src\\main\\resources\\original.txt.gpg";
    //Decrypted sample text file
    public static String pgpDecryptedFilePath="src\\main\\resources\\decrypted.txt";
    //PGP private key passphrase
    public static String pgpPassPhrase = "B4ck To Th3 Futur3";
}