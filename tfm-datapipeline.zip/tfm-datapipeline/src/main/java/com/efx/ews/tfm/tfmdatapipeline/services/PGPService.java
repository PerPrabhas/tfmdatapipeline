package com.efx.ews.tfm.tfmdatapipeline.services;

import org.apache.beam.sdk.io.FileSystems;
import org.apache.beam.sdk.util.MimeTypes;
import org.bouncycastle.openpgp.PGPException;

import java.io.*;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.security.NoSuchProviderException;

public class PGPService {

    private static InputStream publicKeyInputStream;
    private static OutputStream encryptedFileOutputStream;

    private static InputStream privateKeyInputStream;
    private static InputStream encryptedFileInputStream;
    private static OutputStream decryptedFileOutputStream;

    public static void encrypt(String publicKey, String encryptedFilePath, String fileToEncrypt) throws IOException, PGPException, NoSuchProviderException {
        ReadableByteChannel inputChannel = FileSystems.open(FileSystems.matchNewResource(publicKey, false));
        publicKeyInputStream = Channels.newInputStream(inputChannel);

        WritableByteChannel writeChannel = FileSystems.create(FileSystems.matchNewResource(encryptedFilePath, false), MimeTypes.TEXT);
        encryptedFileOutputStream = Channels.newOutputStream(writeChannel);

        PGPEncryptDecryptHelperService.getInstance().encryptFile(encryptedFileOutputStream,fileToEncrypt, PGPEncryptDecryptHelperService.getInstance().readPublicKey(publicKeyInputStream),false,true);
        publicKeyInputStream.close();
        encryptedFileOutputStream.close();
        System.out.format("Original Filename:%s successfully encrypted to:%s", fileToEncrypt, encryptedFilePath);
    }

    public static void decrypt(String encryptedFilePath, String privateKey, String plainTextFile, String passwd) throws Exception {
        ReadableByteChannel inputChannelEncFile = FileSystems.open(FileSystems.matchNewResource(encryptedFilePath, false));
        encryptedFileInputStream = Channels.newInputStream(inputChannelEncFile);

        ReadableByteChannel inputChannelPrivateKey = FileSystems.open(FileSystems.matchNewResource(privateKey, false));
        privateKeyInputStream = Channels.newInputStream(inputChannelPrivateKey);

        decryptedFileOutputStream = new FileOutputStream(plainTextFile);

        PGPEncryptDecryptHelperService.getInstance().decryptFile(encryptedFileInputStream, decryptedFileOutputStream, privateKeyInputStream, passwd.toCharArray());
        encryptedFileInputStream.close();
        decryptedFileOutputStream.close();
        privateKeyInputStream.close();
        System.out.format("Encrypted Filename:%s   successfully decrypted to:%s", encryptedFilePath, plainTextFile);
    }
}
