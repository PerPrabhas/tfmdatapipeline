package com.efx.ews.tfm.tfmdatapipeline;

import com.efx.ews.tfm.tfmdatapipeline.config.Constants;
import com.efx.ews.tfm.tfmdatapipeline.services.CsvToPostgresDB;
import com.efx.ews.tfm.tfmdatapipeline.services.PGPEncryptDecryptHelperService;
import com.efx.ews.tfm.tfmdatapipeline.services.PGPService;
import com.efx.ews.tfm.tfmdatapipeline.services.SchemaGeneratorService;
import lombok.RequiredArgsConstructor;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.SerializableCoder;
import org.apache.beam.sdk.io.FileSystems;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.jdbc.JdbcIO;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.bouncycastle.openpgp.PGPException;

import java.io.*;
import java.math.BigDecimal;
import java.security.NoSuchProviderException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@RequiredArgsConstructor
public class TfmDatapipelineApplication {

	public static void main(String[] args) throws Exception {

		TfmDataPipelineOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(TfmDataPipelineOptions.class);
		FileSystems.setDefaultPipelineOptions(options);
		Pipeline pipeline = Pipeline.create(options);

		CsvToPostgresDB.SetTableInformation(options);

		PCollection<CsvToPostgresDB.DataProcesser> test= pipeline.apply("Read CSV files", TextIO.read().from(options.getInputFile()))
				.apply("Convert to SQL Query",
						ParDo.of(new CsvToPostgresDB.ConvertCSVtoPostgresQuery())).setCoder(SerializableCoder.of(CsvToPostgresDB.DataProcesser.class));

		test.apply(JdbcIO.<CsvToPostgresDB.DataProcesser> write()
				.withDataSourceConfiguration(JdbcIO.DataSourceConfiguration.create("org.postgresql.Driver",options.getConnectionString()))
				.withStatement("Insert into " + options.getTableDetail().getTableName() +"(" + options.getColumnCollection()+  " ) values ("+ options.getParameterCollection()  +")")
				.withPreparedStatementSetter(CsvToPostgresDB::ProcessPreparedStatement));

//		pipeline.apply("Read CSV File", read().from(options.getInputFileName()))
//				.apply("Convert to Json", ParDo.of(new ConvertCSVToJson(options.getJsonSchema())))
//				.apply("write Json to GCS", TextIO.write().to(options.getOutputFolder()).withSuffix(".txt"));

//		PCollection<String> lines = pipeline.apply(
//				"Read Lines From File", TextIO.read().from(options.getInputFileName()));
//
//		PCollection<String> wordLengths = lines.apply("do some processing", ParDo.of(new ComputeWordLengthFn()));
//
//		wordLengths.apply("Write My File", TextIO.write().to(options.getOutputFile()));

//		PCollection<String> csvRows = pipeline.apply("Read from CSV",
//				TextIO.read().from(options.getInputFileName()));

//		PCollection<KV<String, Long>> ratingsCounts = csvRows
//				.apply("Extract Ratings",
//						FlatMapElements.into(TypeDescriptors.strings())
//								.via(csvRow -> Arrays.asList(csvRow.split("|"))))
//				.apply("Count Ratings", Count.<String>perElement());

//		csvRows.apply("Write to CSV", TextIO.write().to(options.getOutputFile()));

//		String csvFile = "/Users/prabhakaranperiasamy/Desktop/GCP_Projects/tfm-datapipeline/src/main/resources/EssentialsObfuscationMapping.csv";
//		String sqlFile = "/Users/prabhakaranperiasamy/Desktop/GCP_Projects/tfm-datapipeline/src/main/resources/EssentialsObfuscationMapping.sql";
//		String jsonFile = "/Users/prabhakaranperiasamy/Desktop/GCP_Projects/tfm-datapipeline/src/main/resources/jsonSchema";
//		String outputFile = "/Users/prabhakaranperiasamy/Desktop/GCP_Projects/tfm-datapipeline/src/main/resources/sqlOutput.csv";

//		SchemaGeneratorService.generateSql(options.getCsvtosqlInputFile().get(),options.getSqlOutputFile().get());
//		SchemaGeneratorService.generateJsonFiles(options.getSqltojsonInputFile().get(),options.getSqltojsonOutputfiles().get());
//		PGPService.encrypt(options.getPgpPublicKey().get(), options.getPgpEncryptedFilePath().get(), options.getFileToPgpEncrypt().get());
		// PGPService.decrypt(options.getPgpEncryptedFilePath().get(), options.getPgpPrivateKey().get(), options.getPgpDecryptedFilePath().get(), Constants.pgpPassPhrase);
		pipeline.run();
	}

}