package com.efx.ews.tfm.tfmdatapipeline.models;


import lombok.Data;

@Data
public class ColumnDetail {
    private String columnName;
    private int columnOrderId;
    private String columnType;
    private String encryptColumn;
}
