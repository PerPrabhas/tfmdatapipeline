package com.efx.ews.tfm.tfmdatapipeline.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Strings;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.efx.ews.tfm.tfmdatapipeline.models.TableDetail;
import com.efx.ews.tfm.tfmdatapipeline.models.ColumnDetail;
import com.efx.ews.tfm.tfmdatapipeline.models.TableInfo;
import org.apache.beam.sdk.io.FileSystems;
import org.apache.beam.sdk.io.fs.ResourceId;
import org.apache.beam.sdk.util.MimeTypes;

import static com.efx.ews.tfm.tfmdatapipeline.config.Constants.*;

public class SchemaGeneratorService {

    public static void generateJsonFiles(String sqlOutputCsv, String jsonOutputFolder){
        Map<String, TableDetail> hashMap = new HashMap<>();
        try (ReadableByteChannel channel = FileSystems.open(
                FileSystems.matchNewResource(sqlOutputCsv, false /* is_directory */));
             BufferedReader br = new BufferedReader(Channels.newReader(channel, StandardCharsets.UTF_8.name())))
        {
            String line="";
            while ((line = br.readLine()) != null) {
                //0 - OrderId, 1 - table Name, 2- Column Name, 3 - dataType  , 4 - fullTable Name, 5 - PII true or false
                String[] data = line.split("\\,");
                TableDetail tableDetail = new TableDetail();
                String tableName = data[4];
                String columnType = data[3];
                String columnName= data[2];
                int orderId = Integer.parseInt(data[0]);
                Boolean isPII = Boolean.parseBoolean(data[5]);
                tableDetail.setTableName(tableName);
                ColumnDetail columnDetail = new ColumnDetail();
                columnDetail.setColumnName(columnName);
                columnDetail.setColumnOrderId(orderId);
                columnDetail.setEncryptColumn(isPII.toString());
                columnDetail.setColumnType(columnType);

                if (hashMap.containsKey(tableName)){
                    TableDetail tb=  hashMap.get(tableName);
                    tb.getFields().add(columnDetail);
                }
                else{
                    List<ColumnDetail> columnDetails= new ArrayList<>();
                    columnDetails.add(columnDetail);
                    tableDetail.setFields(columnDetails);
                    hashMap.put(tableName,tableDetail);
                }
            }
            saveSchema(jsonOutputFolder,hashMap);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void saveSchema(String schemaDirLocation, Map<String, TableDetail> hashMap)
            throws IOException {

        for (Map.Entry<String, TableDetail> entry : hashMap.entrySet()) {
            if (!Strings.isNullOrEmpty(entry.getKey())) {
                TableDetail tableDetail = entry.getValue();
                ObjectMapper mapper = new ObjectMapper();
                String jsonFile = schemaDirLocation + escapeSlash + entry.getKey() + jsonExtn;
                ResourceId resourceId = FileSystems.matchNewResource(jsonFile, false);
                WritableByteChannel fileWriter = FileSystems.create(resourceId, MimeTypes.TEXT);
                fileWriter.write(ByteBuffer.wrap((mapper.writeValueAsString(tableDetail)).getBytes()));
                fileWriter.close();
            }
        }
    }

    public static void generateSql(String piiFileNameArg, String sqlFileNameArg) throws IOException {
        File piiFile= new File(piiFileNameArg);
        Map<String, List<TableInfo>> hashMap = new HashMap<>();
        try (ReadableByteChannel channel = FileSystems.open(
                FileSystems.matchNewResource(piiFileNameArg, false /* is_directory */));
             BufferedReader br = new BufferedReader(Channels.newReader(channel, StandardCharsets.UTF_8.name()))){

            String line = br.readLine();
            while ((line = br.readLine()) !=null){
                String[] splitLine = line.split(",");

                String[] excludeDboDetails = splitLine[0].split("\\.");
                String hashKeyValue = excludeDboDetails.length>1?excludeDboDetails[1]:splitLine[0];
                TableInfo tableInfo = new TableInfo();
                tableInfo.setTableName(splitLine[0]);
                tableInfo.setColumnName(splitLine[1]);
                tableInfo.setPII(splitLine[2].equalsIgnoreCase("yes")?true:false);
                if (hashMap.containsKey(hashKeyValue)){
                    hashMap.get(hashKeyValue).add(tableInfo);
                }
                else{
                    List<TableInfo> columnDetails = new ArrayList<>();
                    columnDetails.add(tableInfo);
                    hashMap.put(hashKeyValue, columnDetails );
                }
            }
        }

        ResourceId resourceId = FileSystems.matchNewResource(sqlFileNameArg, false);

        try (WritableByteChannel fileWriter = FileSystems.create(resourceId, MimeTypes.TEXT)){
            String buildQuery = null;
            String buildCaseStatement = "";
            for (Map.Entry mapElement : hashMap.entrySet()){
                List<TableInfo>  columnDetails = (List<TableInfo>) mapElement.getValue();
                String tableNameAsKey = (String) mapElement.getKey();
                String realTableName="";
                for (TableInfo tableInfo : columnDetails){
                    if (tableInfo.isPII()==true){
                        buildCaseStatement= buildCaseStatement + addWhen.replace("COLUMN_NAME",tableInfo.getColumnName());
                    }
                    realTableName=tableInfo.getTableName();
                }
                buildQuery= startQuery  +"'" +  realTableName + "' as fullTableName, "   + (Strings.isNullOrEmpty(buildCaseStatement) ? defaultWithoutCase: startcase + buildCaseStatement +  endCase )+ endQuery.replace("TABLE_NAME", tableNameAsKey);
                fileWriter.write(ByteBuffer.wrap(buildQuery.getBytes()));
                if (!hashMap.isEmpty()){
                    fileWriter.write(ByteBuffer.wrap("\nunion\n".getBytes()));
                }
                buildCaseStatement = "";

            }
            fileWriter.write(ByteBuffer.wrap("\n order by table_name,column_id \n".getBytes()));
        }
    }
}
