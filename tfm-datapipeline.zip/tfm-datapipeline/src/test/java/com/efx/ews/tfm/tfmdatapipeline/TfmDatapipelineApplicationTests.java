package com.efx.ews.tfm.tfmdatapipeline;

class TfmDatapipelineApplicationTests {

	void contextLoads() {
	}

}
